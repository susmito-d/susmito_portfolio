# Media Gallery Update — files to copy into your repo

## New file
- components/MediaGallery.tsx  (new — lightbox gallery with arrows, keyboard nav, swipe, image/video/audio support)

## Replace existing files
- lib/projects.ts               (adds MediaItem type + optional `media` array on Project)
- app/work/[slug]/page.tsx      (swaps the static hero image for <MediaGallery />)

## How to apply
1. Copy these 3 files into the matching paths in your repo (overwrite the existing two, add the new one).
2. To add more photos/videos/sound to a project, edit lib/projects.ts and add entries to that project's `media` array, e.g.:

   media: [
     { type: "image", src: "/projects/aeon-shield.jpg" },
     { type: "image", src: "/projects/aeon-shield-2.jpg" },
     { type: "video", src: "/projects/aeon-shield-demo.mp4" },
     { type: "audio", src: "/projects/aeon-shield-theme.mp3" },
   ]

   Put the actual media files in public/projects/ first.

3. Then:
   git add .
   git commit -m "Add media gallery with lightbox for project case studies"
   git push
